(function() {

  angular.module('system-feedback', []).controller("ToolbarSystemFeedbackCtrl", [
    "$scope", "$rootScope", "$translate", "context", '$http', 'mail', 'authorize', 'messager', function($scope, $rootScope, $translate, context, $http, mail, authorize, messager) {
      var tool;
      tool = {
        getBrowerInfo: function() {
          var browerArr;
          browerArr = [];
          browerArr.push('appVersion:' + navigator.appVersion);
          browerArr.push('language:' + navigator.language);
          browerArr.push('userAgent:' + navigator.userAgent);
          browerArr.push('vendor:' + navigator.vendor);
          browerArr.push('screenWidth:' + screen.width);
          browerArr.push('screenHeight:' + screen.height);
          return browerArr;
        }
      };
      $scope.entity || ($scope.entity = {});
      $scope.entity.includeScreenshot = true;
      $scope.entity.sendBrowerInfo = true;
      $scope.showDialog = function() {
        if ($scope.entity) {
          $scope.entity.Description = '';
        }
        return html2canvas(document.body, {
          taintTest: false,
          onrendered: function(canvas) {
            $scope.imgSrc = canvas.toDataURL();
            $http.post(NEG.NewkitAPI + '/upload-image', {
              file: $scope.imgSrc
            }).success(function(data, status, headers, config) {
              return $scope.imgSrcUrl = data.file;
            });
            $scope.modalDialog = true;
            return $scope.$apply();
          }
        });
      };
      $scope.closeModal = function() {
        return $scope.modalDialog = false;
      };
      $scope.showBrowerInfo = function() {
        return alert(tool.getBrowerInfo().join('\n'));
      };
      return $scope.save = function() {
        var accountInfo, emailBody, emailSubject, emailTo, entity;
        if (!authorize.accountInfo.EmailAddress) {
          messager.error('Can not get your email address!');
          return;
        }
        entity = $scope.entity;
        accountInfo = authorize.accountInfo;
        emailSubject = 'NewKit：User ' + accountInfo.FullName + ' Feedback!';
        emailBody = '<style>td{border-top:1px solid darkgray;border-left:1px solid darkgray; } .label{border-left: none;}</style>User <b>' + accountInfo.FullName + '</b> Feedback:<br/><br /><div style="color:darkred;">' + entity.Description.replace(/\n/g, '<br />') + '</div><br />' + '<br /><b>Screenshot:</b><br /><br/>' + '<a href="' + $scope.imgSrcUrl + '" target="_blank">' + '<img src="' + $scope.imgSrcUrl + '" width="720" /></a>' + '<br/><i>Click to see original image</i><br /><br /><br/>' + '<table cellpadding="0" cellspacing="0" style="border:1px solid darkgray;">' + '<tr><th colspan="2" style="background: #B8CCE4;">User Info</th></tr>' + '<tr><td class="label">User</td><td>' + accountInfo.UserID + '</td></tr>' + '<tr><td class="label">Department</td><td>' + accountInfo.Department + '</td></tr>' + '<tr><td class="label">IpAddress</td><td>' + accountInfo.IpAddress + '</td></tr>' + '<tr><td class="label">Date</td><td>' + (new Date()) + '</td></tr>' + '<tr><td class="label">URL</td><td>' + location.href + '</td></tr>';
        if (entity.sendBrowerInfo) {
          emailBody = emailBody + '<tr><th colspan="2" style="background: #D6E3BC;">Brower Info</th></tr>' + '<tr><td class="label">App Version</td><td>' + navigator.appVersion + '</td></tr>' + '<tr><td class="label">Language</td><td>' + navigator.language + '</td></tr>' + '<tr><td class="label">User Agent</td><td>' + navigator.userAgent + '</td></tr>' + '<tr><td class="label">Vendor</td><td>' + navigator.vendor + '</td></tr>' + '<tr><td class="label">Screen Width</td><td>' + screen.width + '</td></tr>' + '<tr><td class="label">Screen Height</td><td>' + screen.height + '</td></tr>';
        }
        emailBody += '</table>';
        emailTo = 'gpteammisnesccnbackendtechsupport@newegg.com;';
        if (NEG.Env === "prd") {
          emailTo = emailTo + 'Garry.X.Gu@newegg.com;James.J.Xiao@newegg.com';
        }
        return mail.sendMail(emailTo, emailSubject, emailBody, accountInfo.EmailAddress, function(isSucceed, data) {
          if (isSucceed) {
            messager.success('Thank you for your feedback!');
            return $scope.modalDialog = false;
          } else {
            return messager.error('Feedback has a error,please try again!');
          }
        });
      };
    }
  ]);

}).call(this);

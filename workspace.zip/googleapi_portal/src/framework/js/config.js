var NEG = NEG || {};

NEG.title = "Newegg Central 2.0"
NEG.Env = "placeHolder";
NEG.debug = true;
NEG.DomainName = "Newkit";
//Log的相关配置，主要用于记录客户端的Log
NEG.LogGlobal="NeweggCentral2.0";
NEG.LogLocal="Client";
NEG.LogCategory="ExceptionLog";

NEG.languages={
    'en-us':"English",
    'zh-cn':'简体中文',
    'zh-tw':'繁體中文'
}

if (NEG.Env === "gdev"){
    NEG.NewkitAPI = "http://10.16.75.24:9020"; // Newkit自身API地址，请不要修改
    NEG.deployAPIs = [
      "http://10.16.75.24:9020/deploy"
    ];
    NEG.APIGatewayAddress = "http://10.16.75.24:3000"; //Gateway地址，用于拼接API地址
    NEG.Applications =
    {
        "Newkit": "1f48a705-b734-476c-b32b-29359177c122",
        "NeweggCentral": "dfbc65d8-9205-4336-9521-647f450d8b43",
        "EDI": "8767a1d1-7efe-4666-8646-e0e97bb073e2"
    }
}
else if (NEG.Env === "gqc"){
    NEG.NewkitAPI = "http://10.1.24.145:3000/newegg-central-2/v1"; // Newkit自身API地址，请不要修改
    NEG.deployAPIs = [
        "http://10.1.24.130:8201/newegg-central-2/v1/deploy"
    ];
    NEG.APIGatewayAddress = "http://10.1.24.145:3000"; //Gateway地址，用于拼接API地址
    NEG.Applications =
    {
        "NeweggCentral 2.0": "4b60ee12-3754-4992-9ad5-019a90534302"
    }
}
else if (NEG.Env === "prd"){
    NEG.NewkitAPI = "http://apis.newegg.org/newegg-central-2/v1"; // Newkit自身API地址，请不要修改
    NEG.deployAPIs = [
        "http://10.1.54.110:8201/newegg-central-2/v1/deploy",
        "http://10.1.54.111:8201/newegg-central-2/v1/deploy",
        "http://10.1.54.99:8201/newegg-central-2/v1/deploy",
        "http://10.1.54.100:8201/newegg-central-2/v1/deploy"
    ];
    NEG.APIGatewayAddress = "http://apis.newegg.org"; //Gateway地址，用于拼接API地址
    NEG.Applications =
    {
        "NeweggCentral 2.0": "0915dbb7-27f5-4740-9e50-2bc9c0fb3378"
    }
}
else if (NEG.Env === "prdtesting"){
    NEG.NewkitAPI = "http://sandboxapis.newegg.org/newegg-central-2/v1"; // Newkit自身API地址，请不要修改
    NEG.deployAPIs = [
        "http://10.1.41.205:8201/newegg-central-2/v1/deploy",
        "http://10.1.41.206:8201/newegg-central-2/v1/deploy"
    ];
    NEG.APIGatewayAddress = "http://sandboxapis.newegg.org"; //Gateway地址，用于拼接API地址
    NEG.Applications =
    {
        "NeweggCentral 2.0": "0915dbb7-27f5-4740-9e50-2bc9c0fb3378"
    }
}

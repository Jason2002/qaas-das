angular.module('system-guide-form-elements-time-picker', [])
  .controller("SystemGuideFormDemoTimePickerCtrl", ["$scope", function ($scope) {

  }
]);

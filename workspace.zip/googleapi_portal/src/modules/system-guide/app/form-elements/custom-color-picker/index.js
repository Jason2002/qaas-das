angular.module('system-guide-form-elements-custom-color-picker', [])
  .controller("SystemGuideFormDemoCustomColorPickerCtrl", ["$scope", function ($scope) {
    $scope.colors = [
      "#EEEEEE",
      "#307ECC",
      "#5090C1",
      "#6379AA",
      "#82AF6F",
      "#2E8965",
      "#5FBC47",
      "#E2755F",
      "#E04141",
      "#D15B47",
      "#FFC657",
      "#7E6EB0",
      "#CE6F9E",
      "#404040",
      "#848484"
    ];
    $scope.color="#5FBC47";
  }
]);

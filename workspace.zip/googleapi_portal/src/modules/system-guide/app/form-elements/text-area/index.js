angular.module('system-guide-form-elements-text-area', [])
  .controller("SystemGuideFormDemoTextAreaCtrl", ["$scope", function ($scope) {

  }
]);

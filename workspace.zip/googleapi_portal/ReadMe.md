# Newkit.js

Newkit.js (Newegg Web develop Kit in Javascript) 是一个纯HTML + JS的web framework。

它的前端基于[Angularjs](http://angularjs.org/)，CSS框架基于[ACE](https://wrapbootstrap.com/theme/ace-responsive-admin-template-WB0B30DGR) ([Online Demo](http://10.16.75.10:18888/html))，后端API基于[Node.js](http://nodejs.org/)，数据存储基于[mongoDB](https://www.mongodb.org/)。

类似Newegg Central框架可以实现部署一次，同时挂载多个应用系统（Module）。

我们对web中常用的大部分控件进行了封装（Directives），所以您可以使用它快速的开发web系统，将精力集中于您的业务逻辑中，不用考虑复杂的样式问题。

同时，我们也提供了任何系统都需要的基础构件，包括权限、缓存、配置、日志等。

## Live demo

您可以在[这里](http://10.16.75.27:8886)看到在线演示，使用域帐号或`superuser/superuser`登录。

## Prepare
在开始开发之前, 您可能需要先了解一些基本知识. 我们整理了一些可能会用到的资料, 如下:

* [AngularJS入门教程](http://docs.angularjs.org/tutorial) [(中文)](http://angularjs.cn/T006)
* [AngularJS开发指南](http://docs.angularjs.org/guide) [(中文)](http://www.angularjs.cn/T008) [(中文2)](http://angular.duapp.com/docs/guide)
* [Bootstrap教程](http://v3.bootcss.com/getting-started/)
* [CoffeeScript教程](http://zhang.zipeng.info/library/coffeescript/index.html)

以下是开发中可能会用到的插件:

* Visual Studio - [Web Essentials](http://vswebessentials.com/)
* Web Storm - [Support for AngularJS](http://plugins.jetbrains.com/plugin/6971)
* Chrome - [AngularJS Batarang](https://chrome.google.com/webstore/detail/angularjs-batarang/ighdmehidhipcmcojjgiloacoafjmpfk)

## Download

[下载各个版本开发包](http://trgit2/backend_framework/newkitjs/wikis/release)

## Developer Guide

完整开发文档，请到[这里阅读](http://developer.newegg.org/documentation/newkitjs-developer-guide/intro)

## About us

我们是BTS（Backend Tech Support） team。

欢迎访问我们的[Blog](http://10.16.75.10:8002/)与我们进行交流。

 ![BTS](http://neg-app-img/MISInternal/DocumentTool/20140304042540930_easyicon_net_128.1394693687.ico)
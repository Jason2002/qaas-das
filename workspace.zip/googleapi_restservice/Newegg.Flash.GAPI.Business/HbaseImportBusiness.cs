﻿using Newegg.Flash.GAPI.Data.Interface;
using Ninject;
using System;
using System.Threading.Tasks;
using System.Linq;

namespace Newegg.Flash.GAPI.Business
{
    public class HbaseImportBusiness : BusinessBase
    {
        public bool ImportToHbase(HbaseImportType hbaseImportType)
        {
            var cm = Kernel.Get<IHbaseImport>();

            bool success = false;
            switch (hbaseImportType)
            {
                case HbaseImportType.Defualt:
                    bool[] results = Task.WhenAll<bool>(
                         Task.Run<bool>((Func<bool>)cm.SaveCategoryMappingToHbase),
                         Task.Run<bool>((Func<bool>)cm.SaveSettingToHbase)
                         ).Result;
                    success = results.All(r => r);
                    break;
                case HbaseImportType.CategoryMapping:
                    success = cm.SaveCategoryMappingToHbase();
                    break;
                case HbaseImportType.WebSiteSetting:
                    success = cm.SaveSettingToHbase();
                    break;
                case HbaseImportType.SpecialItems:
                    success = cm.SaveSpecialItemsToHbase();
                    break;
                default:
                    break;
            }
            WriteActionLog(ActionKeys.CountrySetting, ActionType.UPDATE, "ImportToHbase", "");
            return success;
        }
    }
}

﻿using Newegg.Flash.GAPI.Data.Interface;
using Newegg.Flash.GAPI.Data.Interface.Model;
using Newtonsoft.Json;
using Ninject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.GAPI.Business
{
    public class WebSiteInfoBusiness : BusinessBase
    {
        /// <summary>
        /// get website base info
        /// </summary>
        /// <param name="countryCode"></param>
        /// <param name="shipTo"></param>
        /// <param name="channel"></param>
        /// <returns></returns>
        public object GetWebSiteInfo(string countryCode, string shipTo, int? channel)
        {
            var websiteInfo = Kernel.Get<IWebSiteInfo>();
            if (!string.IsNullOrEmpty(countryCode) && !string.IsNullOrEmpty(shipTo) && channel.HasValue)
            {
                var siteInfo = websiteInfo.GetWebSiteDetailInfo(countryCode, shipTo, channel);
                var websiteid = -1;
                if (siteInfo.WebSiteID > 0)
                {
                    websiteid = siteInfo.WebSiteID;
                }
                var categoryInfo = websiteInfo.GetSubCatelogData(websiteid);

                return new { SiteBaseInfo = siteInfo, CategoryInfo = categoryInfo };
            }
            else
            {
                var result = websiteInfo.GetWebSiteBaseInfo(countryCode, shipTo, channel);
                if (string.IsNullOrEmpty(countryCode))
                {
                    return result.Select(x => new
                    {
                         x.CountryCode
                    }).Distinct();
                }
                // select by countrycode
                else if (string.IsNullOrEmpty(shipTo) && !channel.HasValue)
                {
                    return result.Where(x => x.CountryCode.ToLower() == countryCode.Trim().ToLower()).Select(x => new
                    {
                        x.ShipToCountry
                    }).Distinct();
                }
                else
                {

                    // select by countrycode and shipto
                    return new List<object>{ new {
                        Channel =  "NF",
                        Value = 1
                    }, new {
                        Channel =  "Normal",
                        Value =0
                    }}; 
                }
            }


        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="siteBaseInfo"></param>
        /// <param name="setting"></param>
        public object SaveWebSiteSetting(WebSiteInfoDetailData siteBaseInfo, List<SubCategoryGroups> setting, string userID)
        {
            var websiteInfo = Kernel.Get<IWebSiteInfo>();
            try
            {
                //var subCategorys = cm.SaveWebSiteSetting(0);
                //return subCategorys;
                websiteInfo.SaveWebSiteSetting(siteBaseInfo, setting, userID);
                WriteActionLog(ActionKeys.SiteSetting, ActionType.UPDATE, "SITEBASE|" + siteBaseInfo.WebSiteID.ToString(), userID);
                return new { Code = 0, Message = "Save successful." };
            }
            catch
            {
                return new { Code = -1, Message = "Save failed." };
            }
            
        }

        public object SaveSubcategorySetting(WebSiteInfoDetailData webSiteInfoDetailData, bool allPrice)
        {
            var websiteInfo = Kernel.Get<IWebSiteInfo>();
            try
            {
                //var subCategorys = cm.SaveWebSiteSetting(0);
                //return subCategorys;
                websiteInfo.SaveSubcategorySetting(webSiteInfoDetailData, allPrice);
                WriteActionLog(ActionKeys.CategorySetting, ActionType.UPDATE,  "SUBCATE|"+webSiteInfoDetailData.SubcategoryCode.ToString(), webSiteInfoDetailData.LastEditUser);
                return new { Code = 0, Message = "Save successful." };
            }
            catch
            {
                return new { Code = -1, Message = "Save failed." };
            }
        }

        public object GetSubcategorySetting(int websiteID, int subcategory)
        {
            var subcategorySetting = Kernel.Get<IWebSiteInfo>();
            return subcategorySetting.GetSubcategorySetting(websiteID, subcategory);
        }
    }
}

﻿using Newegg.Flash.GAPI.Data.Interface;
using Newegg.Flash.GAPI.Data.Interface.Model;
using System;
using Ninject;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using System.Data.OleDb;

namespace Newegg.Flash.GAPI.Business
{
    public class BulkJobBusiness : BusinessBase
    {
        public object SaveBuklJobData(string strPath, string fileType, int websiteID, string strUser)
        {
            var result = new { Code = 0, Message = "Operating data successfully" };
            try
            {
                var fileInfo = new FileInfo(strPath);
                var strExt = fileInfo.Extension.Replace(".", "");
                string strOdbcCon = "";
                string returnMessage = string.Empty;
                int returnCode = 0;
                if (strExt.ToUpper() == "XLS")
                {
                    strOdbcCon = @"Provider=Microsoft.Jet.OLEDB.4.0; Persist Security Info=False;Data Source=" + strPath + "; Extended Properties=Excel 8.0";
                }
                else if (strExt.ToUpper() == "XLSX")
                {
                    strOdbcCon = @"Provider=Microsoft.ACE.OLEDB.12.0; Persist Security Info=False;Data Source=" + strPath + "; Extended Properties=Excel 12.0";
                }
                else
                {
                    strOdbcCon = @"Provider=Microsoft.Jet.OLEDB.4.0; Persist Security Info=False;Data Source=" + strPath + "; Extended Properties=Excel 8.0";
                }
                //定义OleDbConnection对象实例并连接Excel表格                
                OleDbConnection OleDB = new OleDbConnection(strOdbcCon);
                //定义OleDbDataAdapter对象实例并调用Select查询语句提取Excel数据信息                
                OleDbDataAdapter OleDat = new OleDbDataAdapter("select * from [Sheet1$]", OleDB);
                DataSet ds = new DataSet();
                OleDat.Fill(ds);
                StringBuilder strMessage = new StringBuilder();
                if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {

                    int iCount = 0;
                    bool res = BatchOperationExceptionItem(ds, websiteID, strUser, out iCount);
                    if (res)
                    {
                        strMessage.Append("Operating data successfully. ");
                        string strNewfilename = fileInfo.FullName;
                        strMessage.Append("Uploading successfully, operating data successfully. ");
                        strMessage.AppendFormat(" Total Rows：{0}. ", ds.Tables[0].Rows.Count);
                        strMessage.AppendFormat(" Error Rows：0. ");
                        strMessage.AppendFormat(" Successful");
                    }
                    else
                    {
                        strMessage.Append("Operating data failed. ");
                        string strNewfilename = fileInfo.FullName;
                        strMessage.Append("Uploading successfully, operating data failed. ");
                        strMessage.AppendFormat(" Total Rows：{0}. ", ds.Tables[0].Rows.Count);
                        strMessage.AppendFormat(" Error Rows：0. ");
                        strMessage.AppendFormat(" Failed. ");
                        returnCode = -1;
                    }
                }
                else
                {
                    strMessage.AppendFormat("Load data file failed . ");
                    returnCode = -1;
                }
                returnMessage = strMessage.ToString();

                return new { Code = returnCode, Message = returnMessage.ToString() };
            }
            catch (Exception ex)
            {
                return new { Code = -1, Message = "Load data file failed. " };
            }
            finally
            {
                if (File.Exists(strPath))
                {
                    File.Delete(strPath);
                }
            }
            
        }

        private bool BatchOperationExceptionItem(DataSet ds, int iWebSiteID, string strUser, out int Count)
        {
            if (ds == null || iWebSiteID == 0 || string.IsNullOrEmpty(strUser))
            {
                Count = 0;
                return false;
            }
            var cm = Kernel.Get<IBulkJob>();
            return cm.BatchOperationExceptionItem(ds, iWebSiteID, strUser, out Count);
        } 
    }
}

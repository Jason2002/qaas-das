﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.GAPI.Business
{
    public enum HbaseImportType
    {
        Defualt = 0,
        CategoryMapping = 1,
        WebSiteSetting = 2,
        SpecialItems = 3
    }
}

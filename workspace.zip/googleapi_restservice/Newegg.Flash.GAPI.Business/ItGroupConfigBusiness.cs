﻿using Newegg.Flash.GAPI.Data.Interface;
using Newegg.Flash.GAPI.Data.Interface.Model;
using System;
using Ninject;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.GAPI.Business
{
    public class ItGroupConfigBusiness : BusinessBase
    {
        public object GetItGroupConfigData(string countryCode)
        {
            var cm = Kernel.Get<IWebSiteInfo>();
            var subCategorys = cm.GetPageResultForITGroup(countryCode);
            return subCategorys;
        }

        public object SaveItGroupConfigData(List<SubCategoryGroups> itconfigs, string countryCode, string userID)
        {
            var cm = Kernel.Get<IWebSiteInfo>();
            try
            {
                //var subCategorys = cm.SaveWebSiteSetting(0);
                //return subCategorys;
                cm.SaveItGroupConfig(itconfigs, countryCode, userID);
                WriteActionLog(ActionKeys.CountrySetting, ActionType.UPDATE, countryCode, userID);
                return new { Code = 0, Message = "Save successful." };
            }
            catch
            {
                return new { Code = -1, Message = "Save failed." };
            }
        }

    }
}

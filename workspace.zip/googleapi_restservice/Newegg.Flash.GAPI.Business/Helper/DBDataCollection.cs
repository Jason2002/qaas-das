﻿using Newegg.Flash.GAPI.Data.Interface;
using Newegg.Flash.GAPI.Data.Interface.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace Newegg.Flash.GAPI.Business
{ 
    public class DBDataCollection<T>: CollectionBase
    {
        #region Typed Collection Methods

        /// <summary>
        ///	Adds a new MarginRateSubcategory to the Collection.
        /// </summary>
        /// <param name="value">Product object.</param>
        /// <returns></returns>
        public int Add(T value)
        {
            return List.Add(value);
        }

        /// <summary>
        ///	Adds a new MarginRateSubcategory to the Collection.
        /// </summary>
        /// <returns>Product object.</returns>
        public T AddNew()
        {
            return (T)((IBindingList)this).AddNew();
        }

        public T this[int index]
        {
            get
            {
                return (T)(List[index]);
            }
            set
            {
                List[index] = value;
            }
        }
        /// <summary>
        ///	Removes a DF_SpecialItem object from the Collection.
        /// </summary>
        /// <param name="value">Product object.</param>
        /// <returns></returns>	
        public void Remove(T value)
        {
            List.Remove(value);
        }

        #endregion
    } 
}

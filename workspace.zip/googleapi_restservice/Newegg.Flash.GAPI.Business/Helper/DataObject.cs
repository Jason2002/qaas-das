﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Newegg.Flash.GAPI.Data.Interface.Model
{
    public class DataObject<T>
    {
        public T Body
        {
            get;
            set;
        }

        private List<FaultEntity> faults;

        public List<FaultEntity> Faults
        {
            get
            {
                if (faults == null)
                {
                    faults = new List<FaultEntity>();
                }
                return faults;
            }
            set
            {
                faults = value;
            }
        }
    }


    public class FaultEntity
    {

        public string ErrorCode { get; set; }


        public string ErrorDescription { get; set; }


        public string ErrorDetail { get; set; }
    }
}

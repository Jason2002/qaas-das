﻿using Newegg.Flash.GAPI.Data.Interface;
using Newegg.Flash.GAPI.Data.Interface.Model;
using System;
using System.Web;
using Ninject;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data.OleDb;
using System.Data;
using Newegg.Flash.GAPI.Data;

namespace Newegg.Flash.GAPI.Business
{
    public class KeyWordBusiness : BusinessBase
    {
        public object GetKeyWord(string countryCode, int webSiteID, string keyWord)
        {
            var cm = Kernel.Get<IKeyword>();
            return cm.GetKeyWords(countryCode, webSiteID, keyWord);
        }

        public object DeleteKeyWord(int transactionID, string userID)
        {
            var result = new { Code = 0, Message = "Delete successfull" };
            var cm = Kernel.Get<IKeyword>();
            var resultcount = cm.DeleteKeyWord(transactionID);
            if (resultcount > 0)
            {
                WriteActionLog(ActionKeys.SiteSetting, ActionType.DELETE, "KEYWORD|"+transactionID.ToString(), userID);
                return result;
            }
            else
            {
                return new { Code = -1, Message = "Delete failed" };
            }
        }

        public object SaveKeyWord(KeyWord keyword)
        {
            var cm = Kernel.Get<IKeyword>();
            var result = new { Code = 0, Message = "Save successfull" };

            if (keyword.TransactionID == 0 &&
                cm.IsKeyWordExsits(keyword.CountryCode, keyword.WebsiteID, keyword.Keyword, keyword.FilterType) > 0)
            {
                return new { Code = -1, Message = "Added Failed, the keyword has already existed" };
            }

            if (cm.SaveKeyWord(keyword) > 0)
            {
                WriteActionLog(ActionKeys.SiteSetting, ActionType.UPDATE, "KEYWORD|"+keyword.TransactionID.ToString(), keyword.LastEditUser);
                return result;
            }
            else
            {
                return new { Code = -1, Message = "Save failed" };
            }
        }

    }
}

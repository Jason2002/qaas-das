﻿using Newegg.Flash.GAPI.Data.Interface;
using Newegg.Flash.GAPI.Data.Interface.Model;
using System;
using Ninject;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using System.Data.OleDb;

namespace Newegg.Flash.GAPI.Business
{
    public class SpecialManufacturerBusiness : BusinessBase
    {
        public IEnumerable<SpecialManufacturer> GetManufacturers(int websiteID, int specialType)
        {
            var sm = Kernel.Get<ISpecialManufacturer>();
            return sm.GetSpecialManufacturers(websiteID, specialType);
        }

        public IEnumerable<ManufactoryListItem> GetManufactoryList(int websiteID, int subcategoryCode, int specialType)
        {
            var sm = Kernel.Get<ISpecialManufacturer>();
            if (specialType == 0)
            {
                return sm.GetManufactoryList(websiteID, specialType);
            }
            else if (specialType == 1)
            {
                return sm.GetSubCateManufactoryList(websiteID, subcategoryCode, specialType);
            }
            else
            {
                return new List<ManufactoryListItem>();
            }
        }


        public int SaveExcludeManufacturers(int webSiteID, int specialType, int subCate, IEnumerable<ManufactoryListItem> manufactoryListItem, string userid)
        {
            var sm = Kernel.Get<ISpecialManufacturer>();
            var result = sm.SaveExcludeManufacturers(webSiteID, specialType, subCate, manufactoryListItem,
userid);
            if (result > 0)
                WriteActionLog(ActionKeys.SiteSetting, ActionType.UPDATE, "SPMFC|" + webSiteID.ToString(), userid);
            return result;
        }
    }
}

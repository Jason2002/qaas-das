﻿using Newegg.Flash.GAPI.Data.Interface;
using Newegg.Flash.GAPI.Data.Interface.Model;
using System;
using Ninject;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data.OleDb;
using System.Data;
using Newegg.Flash.GAPI.Data;

namespace Newegg.Flash.GAPI.Business
{
    public class PromotionCodeBusiness : BusinessBase
    {
        public IEnumerable<PromotionCodeData> GetPromotionCode(string PromotionCode, string countryCode, int? type, bool? status, DateTime? start, DateTime? end)
        {
            var cm = Kernel.Get<IPromotionCode>();
            var subCategorys = cm.GetPromotionCode(PromotionCode, countryCode, type, status, start, end);
            return subCategorys;
        }

        public object SavePromotionCode(PromotionCodeData promotioncode)
        {
            var cm = Kernel.Get<IPromotionCode>();
            var message = CheckInput(promotioncode);
            if (string.IsNullOrEmpty(message))
            {
                if (cm.IsPromotionCodeExsits(promotioncode))
                {
                    return new { Code = -1, Message = "this data is already exsits now." };
                }
                else
                {
                    var subCategorys = cm.SavePromotionCode(promotioncode);
                    if (subCategorys > 0)
                        WriteActionLog(ActionKeys.SiteSetting, ActionType.UPDATE, "PROMOCODE|"+promotioncode.PromotionCode, promotioncode.LastEditUser);
                    return subCategorys;
                }
            }
            else
            {
                return new { Code = -1, Message = message };
            }
        }

        private string CheckInput(PromotionCodeData promotioncode)
        {
            var str = promotioncode.PromotionCode;
            if (string.IsNullOrEmpty(str) || str.Contains('<') || str.Contains('&') || str.Contains('%'))
            {
                return "Promotion Code is invalid.";
            }
            var typevaluecheck = IsValidTypeValues(promotioncode);
            if (!string.IsNullOrEmpty(typevaluecheck))
            {
                if (typevaluecheck == "invalid")
                {
                    return "Promotion Code Details is invalid.";
                }
                else if (typevaluecheck == "repeat")
                {
                    return "The values in Promotion Code Details are repeated.";
                }
            }
            if (promotioncode.EndDate.HasValue && promotioncode.EndDate.Value < promotioncode.StartDate)
            {
                return "Start Time is later than End Time";
            }
            return string.Empty;
        }

        public object UpdatePromotionCode(PromotionCodeData promotioncode)
        {
            var message = CheckInput(promotioncode);
            if (string.IsNullOrEmpty(message))
            {
                var cm = Kernel.Get<IPromotionCode>();
                var subCategorys = cm.UpdatePromotionCode(promotioncode);
                if (null != subCategorys)
                    WriteActionLog(ActionKeys.SiteSetting, ActionType.UPDATE, "PROMOCODE|" + promotioncode.PromotionCode, promotioncode.LastEditUser);
                return subCategorys;
            }
            else
            {
                return new { Code = -1, Message = message };
            }
        }

        public object SavePromotionCodeData(string strPath, string fileType, string countryCode, string strUser)
        {
            var result = new { Code = 0, Message = "Operating data successfully" };
            int faultCount = 0;
            try
            {
                var fileInfo = new FileInfo(strPath);
                var strExt = fileInfo.Extension.Replace(".", "");
                string strOdbcCon = "";
                string returnMessage = string.Empty;
                int returnCode = 0;
                DataObject<DBDataCollection<PromotionCodeData>> data = new DataObject<DBDataCollection<PromotionCodeData>>()
                {
                    Body = new DBDataCollection<PromotionCodeData>()
                };
                if (strExt.ToUpper() == "XLS")
                {
                    strOdbcCon = @"Provider=Microsoft.Jet.OLEDB.4.0; Persist Security Info=False;Data Source=" + strPath + "; Extended Properties=Excel 8.0";
                }
                else if (strExt.ToUpper() == "XLSX")
                {
                    strOdbcCon = @"Provider=Microsoft.ACE.OLEDB.12.0; Persist Security Info=False;Data Source=" + strPath + "; Extended Properties=Excel 12.0";
                }
                else
                {
                    strOdbcCon = @"Provider=Microsoft.Jet.OLEDB.4.0; Persist Security Info=False;Data Source=" + strPath + "; Extended Properties=Excel 8.0";
                }
                //定义OleDbConnection对象实例并连接Excel表格                
                OleDbConnection OleDB = new OleDbConnection(strOdbcCon);
                //定义OleDbDataAdapter对象实例并调用Select查询语句提取Excel数据信息                
                OleDbDataAdapter OleDat = new OleDbDataAdapter("select * from [Sheet1$]", OleDB);
                DataSet ds = new DataSet();
                OleDat.Fill(ds);
                StringBuilder strMessage = new StringBuilder();
                var promotioncodeRepo = Kernel.Get<IPromotionCode>();
                var dbhelper = Kernel.Get<IDBHelper>();
                if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    #region  Check Column

                    foreach (DataColumn column in ds.Tables[0].Columns)
                    {
                        column.ColumnName = column.ColumnName.Trim();
                    }

                    if (ds.Tables[0].Columns.Contains("Promotion_ID") == false)
                    {
                        FaultEntity fault = new FaultEntity();
                        fault.ErrorDescription = string.Format("Column Name Promotion_ID does not existed. ");
                        data.Faults.Add(fault);
                    }
                    else if (ds.Tables[0].Columns.Contains("Promotion_Type") == false)
                    {
                        FaultEntity fault = new FaultEntity();
                        fault.ErrorDescription = string.Format("Column Name Promotion_Type does not existed. ");
                        data.Faults.Add(fault);
                    }
                    else if (ds.Tables[0].Columns.Contains("Promotion_Details") == false)
                    {
                        FaultEntity fault = new FaultEntity();
                        fault.ErrorDescription = string.Format("Column Name Promotion_Details does not existed. ");
                        data.Faults.Add(fault);
                    }
                    else if (ds.Tables[0].Columns.Contains("Start_Date_Time") == false)
                    {
                        FaultEntity fault = new FaultEntity();
                        fault.ErrorDescription = string.Format("Column Name Start_Date_Time does not existed. ");
                        data.Faults.Add(fault);
                    }
                    else if (ds.Tables[0].Columns.Contains("End_Date_Time") == false)
                    {
                        FaultEntity fault = new FaultEntity();
                        fault.ErrorDescription = string.Format("Column Name End_Date_Time does not existed. ");
                        data.Faults.Add(fault);
                    }
                    else
                    {
                    #endregion

                        #region prepare data and insert
                        for (int i = 1; i <= ds.Tables[0].Rows.Count; i++)
                        {
                            DataRow row = ds.Tables[0].Rows[i - 1];
                            PromotionCodeData promotionItem = new PromotionCodeData
                            {
                                Status = true,
                                CompanyCode = 1003,
                                CountryCode = countryCode,
                                InUser = strUser,
                                LastEditUser = strUser
                            };
                            if (string.IsNullOrEmpty(row["Promotion_ID"].ToString().Trim()))
                            {
                                FaultEntity fault = new FaultEntity();
                                fault.ErrorDescription = string.Format("Line [{0}] Promotion_ID is required.", i + 1);
                                data.Faults.Add(fault);
                                faultCount++;
                                continue;
                            }
                            promotionItem.PromotionCode = row["Promotion_ID"].ToString().Trim();

                            if (!CheckPromotinCodeString(promotionItem.PromotionCode))
                            {
                                FaultEntity fault = new FaultEntity();
                                fault.ErrorDescription = string.Format("Line [{0}] Promotion_ID is invalid.", i + 1);
                                data.Faults.Add(fault);
                                faultCount++;
                                continue;
                            }

                            if (string.IsNullOrEmpty(row["Promotion_Type"].ToString().Trim()))
                            {
                                FaultEntity fault = new FaultEntity();
                                fault.ErrorDescription = string.Format("Line [{0}] Promotion_Type is required.", i + 1);
                                data.Faults.Add(fault);
                                faultCount++;
                                continue;
                            }
                            int promotionType = GetPromotionType(row["Promotion_Type"].ToString().Trim());
                            if (promotionType < 0)
                            {
                                FaultEntity fault = new FaultEntity();
                                fault.ErrorDescription = string.Format("Line [{0}] Promotion_Type is invalid.", i + 1);
                                data.Faults.Add(fault);
                                faultCount++;
                                continue;
                            }
                            promotionItem.PromotionType = promotionType;

                            if (string.IsNullOrEmpty(row["Promotion_Details"].ToString().Trim()) && promotionItem.PromotionType != 2)
                            {
                                FaultEntity fault = new FaultEntity();
                                fault.ErrorDescription = string.Format("Line [{0}] Promotion_Details is required.", i + 1);
                                data.Faults.Add(fault);
                                faultCount++;
                                continue;
                            }

                            promotionItem.TypeValues = row["Promotion_Details"].ToString().Trim();
                            string valid = string.Empty;
                            valid = IsValidTypeValues(promotionItem);
                            if (valid == "invalid")
                            {
                                FaultEntity fault = new FaultEntity();
                                fault.ErrorDescription = string.Format("Line [{0}] Promotion_Details is invalid.", i + 1);
                                data.Faults.Add(fault);
                                faultCount++;
                                continue;
                            }
                            else if (valid == "repeat")
                            {
                                FaultEntity fault = new FaultEntity();
                                fault.ErrorDescription = string.Format("Line [{0}] the values in Promotion_Details are repeated.", i + 1);
                                data.Faults.Add(fault);
                                faultCount++;
                                continue;
                            }

                            DateTime startTime;
                            if (DateTime.TryParse(row["Start_Date_Time"].ToString(), out startTime))
                            {
                                if (startTime <= dbhelper.GetSQLServerCurrentDate())
                                {
                                    FaultEntity fault = new FaultEntity();
                                    fault.ErrorDescription = string.Format("Line [{0}] Start_Date_Time must be later than current time.", i + 1);
                                    data.Faults.Add(fault);
                                    faultCount++;
                                    continue;
                                }
                                promotionItem.StartDate = startTime;
                            }
                            else
                            {
                                FaultEntity fault = new FaultEntity();
                                if (string.IsNullOrEmpty(row["Start_Date_Time"].ToString()))
                                {
                                    fault.ErrorDescription = string.Format("Line [{0}] Start_Date_Time is required.", i + 1);
                                }
                                else
                                {
                                    fault.ErrorDescription = string.Format("Line [{0}] Start_Date_Time is invalid.", i + 1);
                                }
                                data.Faults.Add(fault);
                                faultCount++;
                                continue;
                            }

                            DateTime endTime;
                            if (DateTime.TryParse(row["End_Date_Time"].ToString(), out endTime))
                            {
                                if (endTime <= startTime)
                                {
                                    FaultEntity fault = new FaultEntity();
                                    fault.ErrorDescription = string.Format("Line [{0}] End_Date_Time must be later than Start_Date_Time.", i + 1);
                                    data.Faults.Add(fault);
                                    faultCount++;
                                    continue;
                                }
                                promotionItem.EndDate = endTime;
                            }
                            else
                            {
                                FaultEntity fault = new FaultEntity();
                                if (!string.IsNullOrEmpty(row["End_Date_Time"].ToString()))
                                {
                                    fault.ErrorDescription = string.Format("Line [{0}] End_Date_Time is invalid.", i + 1);
                                    data.Faults.Add(fault);
                                    faultCount++;
                                    continue;
                                }
                            }

                            if (promotioncodeRepo.IsPromotionCodeExsits(promotionItem))
                            {
                                FaultEntity fault = new FaultEntity();
                                fault.ErrorDescription = string.Format("Line [{0}] data allready exsits.", i + 1);
                                data.Faults.Add(fault);
                                faultCount++;
                                continue;
                            }
                            else
                            {
                                var resultCount = promotioncodeRepo.SavePromotionCode(promotionItem);
                                if (resultCount == 0)
                                {
                                    FaultEntity fault = new FaultEntity();
                                    fault.ErrorDescription = string.Format("Line [{0}] data import failed.", i + 1);
                                    data.Faults.Add(fault);
                                    faultCount++;
                                }
                                else if (resultCount > 0)
                                {
                                    WriteActionLog(ActionKeys.SiteSetting, ActionType.UPDATE, "PROMOCODE|"+promotionItem.PromotionCode, promotionItem.LastEditUser);
                                }

                            }
                            data.Body.Add(promotionItem);
                        }
                        #endregion
                    }
                    StringBuilder promptMessage = new StringBuilder();
                    promptMessage.AppendFormat("{0} imported success, {1} failed.", data.Body.Count == 0 ? 0 : (data.Body.Count - data.Faults.Count + faultCount), data.Body.Count == 0 ? faultCount : data.Faults.Count);

                    if (data.Faults.Count != 0)
                    {
                        foreach (var fault in data.Faults)
                        {
                            promptMessage.Append(fault.ErrorDescription);
                        }
                    }
                    return new
                    {
                        Code = data.Faults.Count == 0 ? 0 : -1,
                        Message = promptMessage.ToString()
                    };

                }
                else
                {
                    strMessage.AppendFormat("Load data file failed");
                    returnCode = -1;
                }
                returnMessage = strMessage.ToString();

                return new { Code = returnCode, Message = returnMessage.ToString() };
            }
            catch (Exception ex)
            {
                return new { Code = -1, Message = "Load data file failed/" + ex.Message };
            }
            finally
            {
                if (File.Exists(strPath))
                {
                    File.Delete(strPath);
                }
            }

        }


        private bool CheckPromotinCodeString(string str)
        {
            if (str.Contains('<') || str.Contains('&') || str.Contains('%'))
            {
                return false;
            }
            return true;
        }

        private bool IsValidCount(string[] arr)
        {
            var d = from n in arr group n by n into g select new { Key = g.Key, Count = g.Count() };
            int max = d.Max(a => a.Count);
            if (max > 1)
            {
                return false;
            }
            return true;
        }

        private string IsValidTypeValues(PromotionCodeData pcode)
        {
            if (pcode.PromotionType == 2)
            {
                return string.Empty;
            }
            int m;
            string[] arr;
            pcode.TypeValues = pcode.TypeValues.Replace('，', ',');
            switch (pcode.PromotionType)
            {
                case 1://Brand
                case 3://SubCategories
                    arr = pcode.TypeValues.Split(',');

                    foreach (string str in arr)
                    {
                        if (!int.TryParse(str, out m))
                        {
                            return "invalid";
                        }
                    }
                    if (!IsValidCount(arr))
                    {
                        return "repeat";
                    }
                    return string.Empty;

                case 4://Items
                    arr = pcode.TypeValues.Split(',');
                    foreach (string str in arr)
                    {
                        if (str.Length > 25)
                        {
                            return "invalid";
                        }
                    }
                    if (!IsValidCount(arr))
                    {
                        return "repeat";
                    }
                    return string.Empty; ;
                case 5: //Brand and SubCategories
                    arr = pcode.TypeValues.Split('|');
                    if (arr.Length != 2)
                    {
                        return "invalid";
                    }
                    else
                    {
                        if (!int.TryParse(arr[0], out m))
                        {
                            return "invalid";
                        }
                        arr = arr[1].Split(',');
                        foreach (string str in arr)
                        {
                            if (!int.TryParse(str, out m))
                            {
                                return "invalid";
                            }
                        }
                        if (!IsValidCount(arr))
                        {
                            return "repeat";
                        }
                    }
                    return string.Empty;
                default: return "invalid"; ;

            }
        }
        private int GetPromotionType(string promotionType)
        {
            switch (promotionType.ToUpper())
            {
                case "BRAND": return 1;
                case "SITEWIDE": return 2;
                case "SUBCATEGORIES": return 3;
                case "ITEMS": return 4;
                case "BRAND & SUBCATEGORY": return 5;
                default: return -1;
            }
        }
    }
}

﻿using Newegg.Flash.GAPI.Data.Interface;
using Ninject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.GAPI.Business
{
    public class BusinessBase
    {
        private static readonly StandardKernel kernel = new StandardKernel(new BusinessModule());

        protected StandardKernel Kernel { get { return kernel; } }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="actionKey">预定义的操作日志key</param>
        /// <param name="at">操作类型： add, delete, update</param>
        /// <param name="detail">操作对象的信息：SiteID, SubCateCode</param>
        /// <param name="user">user id</param>
        /// <returns>inserted log transaction number</returns>
        protected int WriteActionLog(ActionKeys ak, ActionType at, string detail, string user)
        {
            ActionLogs newLog = new ActionLogs();
            newLog.ActionKey = ak.ToString();
            newLog.ActionType = at.ToString();
            newLog.Detail = detail;
            newLog.InUser = user;
            newLog.LastEditUser = user;

            var cm = Kernel.Get<IActionLogs>();
            int result = 0;
            int.TryParse(cm.WriteActionLog(newLog).ToString(), out result);
            return result;
        }
    }
}

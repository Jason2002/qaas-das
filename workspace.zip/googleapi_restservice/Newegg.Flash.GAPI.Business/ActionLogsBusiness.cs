﻿﻿using Newegg.Flash.GAPI.Data.Interface;
using Newegg.Flash.GAPI.Data.Interface.Model;
using System;
using Ninject;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Newegg.Flash.GAPI.Business
{
    public class ActionLogsBusiness : BusinessBase
    {
        ///leave for get method in case
        
       
    }

    public enum ActionType
    {
        ADD,
        DELETE,
        UPDATE
    }

    public enum ActionKeys
    {
        CountrySetting,
        SiteSetting,
        CategorySetting
    }
}

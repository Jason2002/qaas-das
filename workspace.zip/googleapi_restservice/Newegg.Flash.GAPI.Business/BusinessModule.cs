﻿using Newegg.Flash.GAPI.Data;
using Newegg.Flash.GAPI.Data.Implement;
using Newegg.Flash.GAPI.Data.Interface;
using Ninject.Modules;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks; 

namespace Newegg.Flash.GAPI.Business
{
    public class BusinessModule : NinjectModule
    {
        public override void Load()
        {
            Bind<IActionLogs>().To<ActionLogsRepository>();
            Bind<IWebSiteInfo>().To<WebSiteInfoRepository>();
            Bind<ICategoryMapping>().To<CategoryMappingRepository>();
            Bind<IMarginRateSubcategory>().To<MarginRateSubcategoryRepository>();
            Bind<IKeyword>().To<KeywordRepository>();
            Bind<IBulkJob>().To<BulkJobRepository>();
            Bind<ISpecialItem>().To<SpecialItemRepository>();
            Bind<ISpecialManufacturer>().To<SpecialManufacturerRepository>();
            Bind<IPromotionCode>().To<PromotionCodeRepository>();
            Bind<IDBHelper>().To<DBHelperRepository>();
            Bind<IHbaseImport>().To<HbaseImportRepository>();
        }
    }
}

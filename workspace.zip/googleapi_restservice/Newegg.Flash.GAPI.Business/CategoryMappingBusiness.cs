﻿﻿using Newegg.Flash.GAPI.Data.Interface;
using Newegg.Flash.GAPI.Data.Interface.Model;
using System;
using Ninject;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.GAPI.Business
{
    public class CategoryMappingBusiness : BusinessBase
    {
        public object GetCategoryNotMappingData(string actiontype)
        {
            var cm = Kernel.Get<ICategoryMapping>();
            if (actiontype.ToLower().Equals("gnomapping"))
            {
                return cm.GetCategoryNotMappingData().Where(x => x.GoogleCategoryID > 0);
            }
            else
            {
                return cm.GetCategoryNotMappingData().Where(x => x.NeweggCategoryID > 0);
            }
        }

        public object GetGoogleCategorysNeedDelete()
        {
            var cm = Kernel.Get<ICategoryMapping>();
            return cm.GetGoogleCategorysNeedDelete();
        }

        public object GetMappingData()
        {
            var cm = Kernel.Get<ICategoryMapping>();
            var googleCategoryList = new List<GoogleCategory>();
            var neweggCategoryList = new List<NeweggCategory>();
            var googleCategoryTypeList = new List<GoogleCategoryType>();
            var googleCategoryTask = Task.Factory.StartNew(() =>
            {
                googleCategoryList = cm.GetGoogleCategorys().ToList();
            });
            var neweggCategoryTask = Task.Factory.StartNew(() =>
            {
                neweggCategoryList = cm.GetNeweggCategorys().ToList();
            });


            var googleCategoryTypeTask = Task.Factory.StartNew(() =>
            {
                googleCategoryTypeList = cm.GetGoogleCategoryTypes().ToList();
            });

            Task.WaitAll(googleCategoryTask, neweggCategoryTask, googleCategoryTypeTask);
            return new { googleCategoryList, neweggCategoryList, googleCategoryTypeList };
        }

        public object SaveMappingData(CategoryMapping mappingData)
        {
            var result = new { Code = 0, Message = string.Empty };
            if (mappingData.TransactionID >= 0 && mappingData.GoogleCategoryID == -1)
            {
                var cm = Kernel.Get<ICategoryMapping>();
                cm.DeleteCategoryMappingData(mappingData.TransactionID);
                WriteActionLog(ActionKeys.CountrySetting, ActionType.DELETE, mappingData.NeweggCategoryID.ToString(), mappingData.LastEditUser);
                result = new
                {
                    Code = 0,
                    Message = "Delete successfull"
                };
            }
            else
            {
                if(mappingData.TransactionID == 0 && mappingData.GoogleCategoryID==0 && mappingData.NeweggCategoryID ==0)
                    return new
                    {
                        Code = -2,
                        Message = "Save Failed, emtpy data!"
                    };

                var cm = Kernel.Get<ICategoryMapping>();
                var masterCategoryName = cm.NeweggCategoryIsExists(mappingData.NeweggCategoryID, mappingData.TransactionID);
                if (!string.Empty.Equals(masterCategoryName))
                {
                    //
                    return new
                    {
                        Code = -1,
                        Message = string.Format("Newegg Category [{0}] has been select Google Master Category[{1}].", mappingData.NeweggCategoryName, masterCategoryName)
                    };
                }
                var saveresult = cm.SaveCategoryMappingData(mappingData);
                if (null != saveresult)
                {
                    WriteActionLog(ActionKeys.CountrySetting, ActionType.UPDATE, "NCATEID|" + mappingData.NeweggCategoryID.ToString() + "|GCATEID|" + mappingData.GoogleCategoryID.ToString(), mappingData.LastEditUser);
                    result = new
                    {
                        Code = 0,
                        Message = "Save successfull"
                    };
                }
                else
                {

                    result = new
                    {
                        Code = -1,
                        Message = "Save failed"
                    };
                }
            }
            return result;
        }

        public object GetMappingData(string googleName, string neweggName, bool isMaster)
        {

            var cm = Kernel.Get<ICategoryMapping>();
            return cm.GetCategoryMappingData(googleName, neweggName, isMaster).ToList();
        }

        public object DeleteMappingDataWithInvalidGoogleID(string inUser)
        {
            var cm = Kernel.Get<ICategoryMapping>();
            WriteActionLog(ActionKeys.CountrySetting, ActionType.DELETE, "DeleteMappingDataWithInvalidGoogleID", inUser);
            return cm.DeleteMappingDataWithInvalidGoogleID();
        }
    }
}

﻿using Newegg.Flash.GAPI.Data.Interface;
using Newegg.Flash.GAPI.Data.Interface.Model;
using System;
using Ninject;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using System.Data.OleDb;

namespace Newegg.Flash.GAPI.Business
{
    public class SpecialItemBusiness : BusinessBase
    {
        public object GetSpecialItems(int websiteID, string itemNumber, DateTime? startTime, DateTime? endTime)
        {
            var specialItem = Kernel.Get<ISpecialItem>();
            return specialItem.GetSpecialItemList(websiteID, itemNumber, startTime, endTime);
        }

        public object SaveSpecialItems(SpecialItem specialItem)
        {
            var dataAccess = Kernel.Get<ISpecialItem>();

            if (dataAccess.ItemIsExists(specialItem.ItemNumber) > 0)
            {

                // get item catalog
                specialItem.ItemCatalog = dataAccess.GetCatalogByItem(specialItem.ItemNumber);

                if (specialItem.ItemCatalog == -1)
                {
                    return new { Code = -1, Message = "item category code exception" };
                }
                var exsitsTransactionID = dataAccess.IsSpecialItemExsits(specialItem.WebsiteID, specialItem.ItemNumber, specialItem.ItemCatalog);

                //  already exsits
                if (exsitsTransactionID > 0 && exsitsTransactionID != specialItem.TransactionID)
                {
                    return new { Code = -1, Message = "item already exists." };
                }
            }
            else
            {
                return new { Code = -1, Message = "item not exists." };
            }

            var successCount = dataAccess.SaveSpecialItem(specialItem);
            WriteActionLog(ActionKeys.SiteSetting, ActionType.UPDATE, "SPITEM|" + specialItem.ItemNumber, specialItem.LastEditUser);
            return new { Code = successCount, Message = "Save successfull" };
        }

        public object DeleteSpecialItem(int transactionID,string userid)
        {
            var dataAccess = Kernel.Get<ISpecialItem>();
            int result = dataAccess.DeleteSpecialItem(transactionID);
            if (result > 0)
                WriteActionLog(ActionKeys.SiteSetting, ActionType.DELETE, "SPITEM|" + transactionID.ToString(), userid);
            return result;
        }
    }
}

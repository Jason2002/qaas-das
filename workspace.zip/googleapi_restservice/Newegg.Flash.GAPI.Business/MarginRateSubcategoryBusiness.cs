﻿using Newegg.Flash.GAPI.Data.Interface;
using Newegg.Flash.GAPI.Data.Interface.Model;
using System;
using System.Web;
using Ninject;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data.OleDb;
using System.Data;

namespace Newegg.Flash.GAPI.Business
{
    public class MarginRateSubcategoryBusiness : BusinessBase
    {
        public object GetMarginRates(string countryCode, int subcategoryCode, string label)
        {
            var cm = Kernel.Get<IMarginRateSubcategory>();
            if (string.IsNullOrEmpty(countryCode))
            {
                countryCode = "USA";
            }
            var marginRates = cm.GetMarginRates(countryCode, subcategoryCode, label);
            return marginRates;
        }

        public object DeleteMarginRateSubcategory(IEnumerable<MarginRateSubcategory> marginRates)
        {
            var cm = Kernel.Get<IMarginRateSubcategory>();

            foreach (var rate in marginRates)
            {
                cm.DeleteMarginRate(rate);
                WriteActionLog(ActionKeys.SiteSetting, ActionType.DELETE, "MARGINLABLE|"+rate.MarginRateLabel, rate.LastEditUser);
            }
            return null;
        }

        public object SaveMarginRateSubcategory(MarginRateSubcategory[] marginRates)
        {
            var cm = Kernel.Get<IMarginRateSubcategory>();
            var result = new { Code = 0, Message = "Save successfull" };
            var exsits = 0;
            foreach (var rate in marginRates)
            {
                exsits = cm.CheckMarginDataIsExist(rate.SubcategoryCode, rate.CountryCode);
                if (exsits > 0 && exsits != rate.TransactionID)
                {
                    result = new { Code = -1, Message = "CatagoryCode Is Allready Exist." };
                }
                else
                {
                    if (cm.CheckCatagoryCodeIsExist(rate.SubcategoryCode))
                    {
                        if (cm.SaveMarginRate(rate) > 0)
                            WriteActionLog(ActionKeys.SiteSetting, ActionType.UPDATE, "MARGINLABLE|"+rate.MarginRateLabel, rate.LastEditUser);
                    }
                    else
                    {
                        result = new { Code = -1, Message = "SubcategoryCode must be valid!" };
                    }
                }
            }
            return result;
        }


        public object LoadAndProcessFileData(string fileUrl, string fileType, string countryCode, string userID)
        {
            var cm = Kernel.Get<IMarginRateSubcategory>();
            int result = 0;
            int add_result = 0;
            int modify_result = 0;
            var resultObj = new { Code = 0, Message = "Save Succesfull." };
            try
            {
                int faultCount = 0;
                DataObject<DBDataCollection<MarginRateSubcategory>> data = new DataObject<DBDataCollection<MarginRateSubcategory>>()
                {
                    Body = new DBDataCollection<MarginRateSubcategory>()
                };
                string strOdbcCon = "";
                if (fileType.ToLower() == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                {
                    strOdbcCon = @"Provider=Microsoft.ACE.OLEDB.12.0; Persist Security Info=False;Data Source=" + fileUrl + "; Extended Properties=Excel 12.0";
                }
                else
                {
                    strOdbcCon = @"Provider=Microsoft.Jet.OLEDB.4.0; Persist Security Info=False;Data Source=" + fileUrl + "; Extended Properties=Excel 8.0";
                }
                //定义OleDbConnection对象实例并连接Excel表格                
                using (OleDbConnection OleDB = new OleDbConnection(strOdbcCon))
                {
                    //定义OleDbDataAdapter对象实例并调用Select查询语句提取Excel数据信息                
                    OleDbDataAdapter OleDat = new OleDbDataAdapter("select * from [Sheet1$]", OleDB);
                    DataSet ds = new DataSet();
                    OleDat.Fill(ds);
                    if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                    {
                        #region  Check Column

                        foreach (DataColumn column in ds.Tables[0].Columns)
                        {
                            column.ColumnName = column.ColumnName.Trim();
                        }

                        if (ds.Tables[0].Columns.Contains("subcategorycode") == false)
                        {
                            FaultEntity fault = new FaultEntity();
                            fault.ErrorDescription = string.Format("Column Name subcategorycode does not existed. ");
                            data.Faults.Add(fault);
                        }
                        else if (ds.Tables[0].Columns.Contains("customlabel") == false)
                        {
                            FaultEntity fault = new FaultEntity();
                            fault.ErrorDescription = string.Format("Column Name customlabel does not existed. ");
                            data.Faults.Add(fault);
                        }

                        else
                        {
                        #endregion
                            for (int i = 1; i <= ds.Tables[0].Rows.Count; i++)
                            {
                                DataRow row = ds.Tables[0].Rows[i - 1];
                                if (string.IsNullOrEmpty(row["subcategorycode"].ToString().Trim()))
                                {
                                    FaultEntity fault = new FaultEntity();
                                    fault.ErrorDescription = string.Format("Line [{0}] subcategorycode is required.", i + 1);
                                    data.Faults.Add(fault);
                                    faultCount++;
                                    continue;
                                }
                                if ((!string.IsNullOrEmpty(row["subcategorycode"].ToString().Trim()) && row["subcategorycode"].ToString().Trim().Length > 10))
                                {
                                    FaultEntity fault = new FaultEntity();
                                    fault.ErrorDescription = string.Format("Line [{0}] subcategory id length must be less than 10.", i + 1);
                                    data.Faults.Add(fault);
                                    faultCount++;
                                    continue;
                                }
                                string subcategorycode = row["subcategorycode"].ToString().Trim();
                                if (string.IsNullOrEmpty(row["customlabel"].ToString().Trim()))
                                {
                                    FaultEntity fault = new FaultEntity();
                                    fault.ErrorDescription = string.Format("Line [{0}] customlabel is required.", i + 1);
                                    data.Faults.Add(fault);
                                    faultCount++;
                                    continue;
                                }
                                if ((!string.IsNullOrEmpty(row["customlabel"].ToString().Trim()) && row["customlabel"].ToString().Trim().Length > 50))
                                {
                                    FaultEntity fault = new FaultEntity();
                                    fault.ErrorDescription = string.Format("Line [{0}] customlabel length must be less than 50.", i + 1);
                                    data.Faults.Add(fault);
                                    faultCount++;
                                    continue;
                                }
                                if (!cm.CheckCatagoryCodeIsExist(int.Parse(subcategorycode)))
                                {
                                    FaultEntity fault = new FaultEntity();
                                    fault.ErrorDescription = string.Format("Line [{0}] subcategorycode not exists.", i + 1);
                                    data.Faults.Add(fault);
                                    faultCount++;
                                    continue;
                                }
                                string customlabel = row["customlabel"].ToString().Trim();
                                var tid = cm.CheckMarginDataIsExist(int.Parse(subcategorycode), countryCode);
                                if (tid > 0)
                                {
                                    var marginRate = new MarginRateSubcategory
                                    {
                                        TransactionID = tid,
                                        CountryCode = countryCode,
                                        SubcategoryCode = int.Parse(subcategorycode),
                                        CompanyCode = 1003,
                                        MarginRateLabel = customlabel,
                                        LastEditUser = userID,
                                        InUser = userID

                                    };
                                    result = cm.SaveMarginRate(marginRate);
                                    modify_result++;
                                }
                                else
                                {
                                    var marginRate = new MarginRateSubcategory
                                    {
                                        CountryCode = countryCode,
                                        SubcategoryCode = int.Parse(subcategorycode),
                                        CompanyCode = 1003,
                                        MarginRateLabel = customlabel,
                                        LastEditUser = userID,
                                        InUser = userID

                                    };
                                    result = cm.SaveMarginRate(marginRate);
                                    add_result++;
                                }

                                if (result <= 0)
                                {
                                    FaultEntity fault = new FaultEntity();
                                    fault.ErrorDescription = string.Format("Line [{0}] data import failed.", i + 1);
                                    data.Faults.Add(fault);
                                    faultCount++;
                                    continue;
                                }
                                MarginRateSubcategory marginRateSubcategory = new MarginRateSubcategory()
                                {
                                    MarginRateLabel = customlabel
                                };
                                data.Body.Add(marginRateSubcategory);
                            }
                        }
                        StringBuilder marginMessage = new StringBuilder();
                        marginMessage.AppendFormat("{0} imported success,{1} add,{2} modify, {3} failed.", data.Body.Count == 0 ? 0 : (data.Body.Count - data.Faults.Count + faultCount), add_result, modify_result, data.Body.Count == 0 ? faultCount : data.Faults.Count);
                        WriteActionLog(ActionKeys.SiteSetting, ActionType.UPDATE, "MARGINLABLE|"+marginMessage.ToString(), userID);
                        if (data.Faults.Count != 0)
                        {
                            foreach (var fault in data.Faults)
                            {
                                marginMessage.Append(fault.ErrorDescription);
                            }
                        }
                        resultObj = new
                        {
                            Code = data.Faults.Count == 0 ? 0 : -1,
                            Message = marginMessage.ToString()
                        };
                    }
                    else
                    {
                        resultObj = new
                        {
                            Code = -1,
                            Message = "Load data file failed, there is invalid data to import."
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Sheet1$"))
                {
                    resultObj = new
                    {
                        Code = -1,
                        Message = "Operating data failed, not find Sheet1./" + ex.Message
                    };
                }
                else
                {
                    resultObj = new
                    {
                        Code = -1,
                        Message = "Operating data failed." + ex.Message
                    };
                }
            }
            finally
            {
                if (File.Exists(fileUrl))
                {
                    File.Delete(fileUrl);
                }
            }
            return resultObj;
        }
    }
}

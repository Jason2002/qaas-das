﻿using Newegg.Flash.GAPI.Data.Interface;
using Newegg.Oversea.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Newegg.Flash.GAPI.Data.Implement
{
    public class DBHelperRepository : IDBHelper
    {
        public DateTime GetSQLServerCurrentDate()
        {
            var dataCommand = DataCommandManager.GetDataCommand("GetSQLServerCurrentDate");
            return DateTime.Parse(dataCommand.ExecuteScalar().ToString());
        }
    }
}

﻿using EggKeeper.Sdk;
using Newegg.API.Client;
using Newegg.API.Logging;
using Newegg.Flash.GAPI.Data.Interface;
using Newegg.Flash.GAPI.Data.Interface.Model;
using Newegg.Flash.GAPI.Data.Interface.Model.HbaseImport;
using Newegg.Oversea.DataAccess;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Newegg.Flash.GAPI.Data.Implement
{
    public class HbaseImportRepository : IHbaseImport
    {
        RestAPIClient hbaseImportService = null;
        const int MAX_COUNT_PER_REQUEST = 5000;

        public HbaseImportRepository()
        {
            var eggKeeper = EggKeeperFactory.GetEggKeeper();
            var importServiceURL = eggKeeper.GetData<string>("DataFeed_GAPI", "HbaseImportServiceURL", NodeDataType.Text);
            hbaseImportService = new RestAPIClient(importServiceURL);
        }

        #region GoogleCategoryMapping


        public bool SaveCategoryMappingToHbase()
        {
            var dataCommand = DataCommandManager.GetDataCommand("GoogleCategoryMappingForHbase");
            var mappings = dataCommand.ExecuteEntityList<HbaseGoogleCategoryMapping>();
            var postData = new PostData
            {
                tableName = "EC_GAPI_CategoryMapping",
                datas = GetGoogleMappingPostData(mappings),
                clearTableBeforPut = true
            };
            return PostToHbaseAPI(postData);
        }

        private HbaseDataDetail[] GetGoogleMappingPostData(IEnumerable<HbaseGoogleCategoryMapping> mappingData)
        {
            List<HbaseDataDetail> result = new List<HbaseDataDetail>();

            foreach (HbaseGoogleCategoryMapping data in mappingData)
            {
                string rowKey = data.NeweggCategoryID + "|" + data.GoogleCategoryID;
                result.Add(new HbaseDataDetail
                {
                    row = rowKey,
                    column = "BaseInfo",
                    cell = "GoogleCategoryID",
                    value = data.GoogleCategoryID.ToString()
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowKey,
                    column = "BaseInfo",
                    cell = "GoogleCategoryName",
                    value = data.GoogleCategoryName
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowKey,
                    column = "BaseInfo",
                    cell = "NeweggCategoryID",
                    value = data.NeweggCategoryID.ToString()
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowKey,
                    column = "BaseInfo",
                    cell = "GoogleCategoryType",
                    value = data.GoogleCategoryType
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowKey,
                    column = "BaseInfo",
                    cell = "IsMasterCategory",
                    value = data.IsMasterCategory.ToString()
                });
            }

            return result.ToArray();
        }

        #endregion

        #region WebsiteSetting


        public bool SaveSettingToHbase()
        {
            HbaseSettingDetail settingDetails = GetWebsiteSettingForHbase();
            var postData = new PostData
            {
                tableName = "EC_GAPI_WebSiteSetting",
                datas = GetWebSiteSettingPostData(settingDetails),
                clearTableBeforPut = true
            };
            return PostToHbaseAPI(postData);
        }

        private HbaseSettingDetail GetWebsiteSettingForHbase()
        {
            HbaseSettingDetail detail = new HbaseSettingDetail();
            Task.WaitAll(
                Task.Run(() => detail.KeyWords = DataCommandManager.GetDataCommand("GoogleKeyWordsForHbase").ExecuteEntityList<HbaseKeyword>()),
                Task.Run(() => detail.SpecialMFC = DataCommandManager.GetDataCommand("SpecialMFCForHbase").ExecuteEntityList<HbaseSpecialMFC>()),
                Task.Run(() => detail.SubCategoryCodes = DataCommandManager.GetDataCommand("SubCategoryCodesForHbase").ExecuteEntityList<HbaseSubCategoryCodes>()),
                Task.Run(() => detail.WebsiteSetting = DataCommandManager.GetDataCommand("WebsiteSettingForHbase").ExecuteEntityList<HbaseWebsiteSetting>())
            );
            return detail;
        }

        private HbaseDataDetail[] GetWebSiteSettingPostData(HbaseSettingDetail settingData)
        {
            List<HbaseDataDetail> result = new List<HbaseDataDetail>();
            var rowkey = string.Empty;
            foreach (HbaseWebsiteSetting data in settingData.WebsiteSetting)
            {
                rowkey = data.CountryCode + "|" + data.ShipToCountry + "|" + data.Channel + "|" + data.CompanyCode;
                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteBaseInfo",
                    cell = "GoogleKeyWords",
                    value = JsonConvert.SerializeObject(settingData.KeyWords.Where(x => x.WebSiteID == data.WebSiteID))
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteBaseInfo",
                    cell = "SubCategoryCodes",
                    value = JsonConvert.SerializeObject(settingData.SubCategoryCodes.Where(x => x.WebSiteID == data.WebSiteID).ToDictionary(x => x.SubCategorycode))
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteBaseInfo",
                    cell = "SpecialMFC",
                    value = JsonConvert.SerializeObject(settingData.SpecialMFC.Where(x => x.WebSiteID == data.WebSiteID).GroupBy(x => x.sc).ToDictionary(x => x.Key))
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteBaseInfo",
                    cell = "WebsiteName",
                    value = data.WebSiteName
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteBaseInfo",
                    cell = "WebsiteID",
                    value = data.WebSiteID.ToString()
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteBaseInfo",
                    cell = "Channel",
                    value = data.Channel.ToString()
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteBaseInfo",
                    cell = "TrackTag",
                    value = data.TrackTag
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteBaseInfo",
                    cell = "ActiveMark",
                    value = data.ActiveMark
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteBaseInfo",
                    cell = "DefaultPromtotionText",
                    value = data.DefaultPromotionText
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteSetting",
                    cell = "CampaignCode",
                    value = data.CampaignCode
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteSetting",
                    cell = "MiniPrice",
                    value = data.MiniPrice.ToString()
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteSetting",
                    cell = "MaxPrice",
                    value = data.MaxPrice.ToString()
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteSetting",
                    cell = "MinQty",
                    value = data.MinQty.ToString()
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteSetting",
                    cell = "L7DQty",
                    value = data.L7DQty.ToString()
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteSetting",
                    cell = "Refurbished",
                    value = data.Refurbished.ToString()
                });
                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteSetting",
                    cell = "OEMItem",
                    value = data.OEMItem.ToString()
                });
                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteSetting",
                    cell = "RetailItem",
                    value = data.RetailItem.ToString()
                });
                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteSetting",
                    cell = "PreOrderItem",
                    value = data.PreOrderItem.ToString()
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteSetting",
                    cell = "Recertified",
                    value = data.Recertified.ToString()
                });
                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteSetting",
                    cell = "HomepageDetail",
                    value = data.HomepageDetail.ToString()
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteSetting",
                    cell = "HasMKT",
                    value = data.HasMKT.ToString()
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteSetting",
                    cell = "ClearanceItem",
                    value = data.ClearanceItem.ToString()
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteSetting",
                    cell = "ReservedFlag1",
                    value = data.ReservedFlag1 ?? string.Empty
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "WebsiteSetting",
                    cell = "ReServedChar1",
                    value = data.ReservedChar1 ?? string.Empty
                });
            }

            return result.Where(x => x.value != null).ToArray();
        }
        #endregion

        #region SpecialItems


        public bool SaveSpecialItemsToHbase()
        {

            var dataCommand = DataCommandManager.GetDataCommand("GetHbaseSpecialItemsMaxID");
            int maxid = dataCommand.ExecuteScalar<int>();

            dataCommand = DataCommandManager.GetDataCommand("HbaseSpecialItemsForHbase");
            int fromID = 0;
            while (fromID < maxid)
            {
                int toID = fromID + MAX_COUNT_PER_REQUEST;
                var items = dataCommand.ExecuteEntityList<HbaseSpecialItems>(new { fromID, toID });
                //数据为空也应该发送Request清空表
                //if (items.Count == 0)
                //    continue; 
                bool success = SaveSpecialItemsToHbaseInternal(items, fromID == 0);
                if (!success)
                    return false;
                fromID = toID;
            }
            return true;
        }

        private bool SaveSpecialItemsToHbaseInternal(IEnumerable<HbaseSpecialItems> specialitems, bool first)
        {
            var postData = new PostData
            {
                tableName = "EC_GAPI_SpecialItems",
                datas = GetSpecialItemsPostData(specialitems),
                clearTableBeforPut = first
            };
            return PostToHbaseAPI(postData);
        }

        private HbaseDataDetail[] GetSpecialItemsPostData(IEnumerable<HbaseSpecialItems> specialitems)
        {
            List<HbaseDataDetail> result = new List<HbaseDataDetail>();

            foreach (HbaseSpecialItems data in specialitems)
            {
                string rowkey = string.Format("{0}|{1}|{2}|{3}|{4}", data.ItemNumber, data.CountryCode, data.CompanyCode.ToString(), data.WebSiteID.ToString(), data.SpecialType.ToString());
                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "BaseInfo",
                    cell = "ActionMark",
                    value = data.ActionMark
                });


                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "BaseInfo",
                    cell = "ItemCatalog",
                    value = data.ItemCatalog.ToString()
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "BaseInfo",
                    cell = "StartTime",
                    value = data.StartTime.ToUnixTimestamp().ToString()
                });

                result.Add(new HbaseDataDetail
                {
                    row = rowkey,
                    column = "BaseInfo",
                    cell = "ExpireTime",
                    value = data.ExpireTime.ToUnixTimestamp().ToString()
                });
            }
            return result.ToArray();
        }

        #endregion

        private bool PostToHbaseAPI(PostData postData)
        {
            ResultClass result = hbaseImportService.Post<ResultClass>("", postData);
            bool sucess = result != null && result.code == 0;
            if (!sucess || !string.IsNullOrEmpty(result.error))
            {
                string error = string.Format("{0:F}--Hbase Import Result failed. tableName:{1}, Data Count:{2}, ClearBeforput:{3}, Reuslt code:{4}, Result Message:{5}",
                    DateTime.Now, postData.tableName, postData.datas.Count(), postData.clearTableBeforPut, result.code, result.error);
                LogFactory.Log.Error(error);
            }
            return sucess;
        }

    }


    public class ResultClass
    {
        public int code { get; set; }

        public string error { get; set; }
    }
}

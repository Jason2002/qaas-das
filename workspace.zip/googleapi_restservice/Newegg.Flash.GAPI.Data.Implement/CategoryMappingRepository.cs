﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.Flash.GAPI.Data.Interface;
using Newegg.Oversea.DataAccess;
using System.Data;
using Newegg.Flash.GAPI.Data.Interface;
using System.Transactions;

namespace Newegg.Flash.GAPI.Data.Implement
{
    public class CategoryMappingRepository : ICategoryMapping
    {
        public int DeleteMappingDataWithInvalidGoogleID()
        {
            var dataCommand = DataCommandManager.GetDataCommand("DeleteMappingDataWithInvalidGoogleID");
            return dataCommand.ExecuteNonQuery();
        }

        public IEnumerable<CategoryMapping> GetCategoryNotMappingData()
        {
            List<CategoryMapping> result = new List<CategoryMapping>();

            var dataCommand = DataCommandManager.GetDataCommand("GetGoogleCategorysNotMapping");
            result = dataCommand.ExecuteEntityList<CategoryMapping>();
            return result;
        }

        public IEnumerable<CategoryMapping> GetGoogleCategorysNeedDelete()
        {
            List<CategoryMapping> result = new List<CategoryMapping>();

            var dataCommand = DataCommandManager.GetDataCommand("GetGoogleCategorysNeedDelete");
            result = dataCommand.ExecuteEntityList<CategoryMapping>();
            return result;
        }

        public IEnumerable<CategoryMapping> GetCategoryMappingData(string googleName, string neweggName, bool isMaster)
        {
            List<CategoryMapping> result = new List<CategoryMapping>();

            var dataCommand = DataCommandManager.CreateCustomDataCommandFromConfig("GetCategoryMappingData");

            using (DynamicQuerySqlBuilder sqlBuilder = new DynamicQuerySqlBuilder(dataCommand, "TransactionID desc"))
            {
                if (!string.IsNullOrEmpty(neweggName))
                {
                    sqlBuilder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "NeweggCategoryName", DbType.String, "@NeweggCategoryName", QueryConditionOperatorType.Like, neweggName);
                }

                //sqlBuilder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "IsMasterCategory", DbType.Boolean, "@IsMasterCategory", QueryConditionOperatorType.Equal, isMaster);

                if (!string.IsNullOrEmpty(googleName))
                {
                    sqlBuilder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "GoogleCategoryName", DbType.String, "@GoogleCategoryName", QueryConditionOperatorType.Like, googleName);
                }

                //查询数据
                dataCommand.CommandText = sqlBuilder.BuildQuerySql();
                result = dataCommand.ExecuteEntityList<CategoryMapping>();
            }

            return result;
        }

        public IEnumerable<NeweggCategory> GetNeweggCategorys()
        {
            List<NeweggCategory> result = new List<NeweggCategory>() { 
                new NeweggCategory { NeweggCategoryID = 0, NeweggCategoryName = ""
                } };

            var dataCommand = DataCommandManager.GetDataCommand("GetNeweggCategorys");
            result.AddRange(dataCommand.ExecuteEntityList<NeweggCategory>());
            return result;
        }

        public IEnumerable<GoogleCategory> GetGoogleCategorys()
        {
            List<GoogleCategory> result = new List<GoogleCategory>()
            {   new GoogleCategory{
                    GoogleCategoryID = 0,
                  GoogleCategoryName = ""
                }
            };

            var dataCommand = DataCommandManager.GetDataCommand("GetGoogleCategorys");
            result.AddRange(dataCommand.ExecuteEntityList<GoogleCategory>());
            return result;
        }


        public IEnumerable<GoogleCategoryType> GetGoogleCategoryTypes()
        {
            List<GoogleCategoryType> result = new List<GoogleCategoryType>();
            result.Add(new GoogleCategoryType { TypeID = "", TypeName = "All other products" });
            result.Add(new GoogleCategoryType { TypeID = "1", TypeName = "Group non apparel" });
            result.Add(new GoogleCategoryType { TypeID = "2", TypeName = "Group shoes sunglasses handbags watches" });
            result.Add(new GoogleCategoryType { TypeID = "3", TypeName = "Group other apparel" });
            result.Add(new GoogleCategoryType { TypeID = "4", TypeName = "Ungroup shoes sunglasses handbags watches" });
            result.Add(new GoogleCategoryType { TypeID = "5", TypeName = "Ungroup other apparel" });
            result.Add(new GoogleCategoryType { TypeID = "6", TypeName = "Custom goods" });
            result.Add(new GoogleCategoryType { TypeID = "7", TypeName = "Media video game software" });
            result.Add(new GoogleCategoryType { TypeID = "8", TypeName = "Book" });
            return result;
        }

        public object SaveCategoryMappingData(CategoryMapping mappingData)
        {
            var dataCommand = DataCommandManager.GetDataCommand("SaveCategoryMappingData");
            var p = new DynamicParameters();
            p.Add("@GoogleCategoryID", mappingData.GoogleCategoryID);
            p.Add("@GoogleCategoryName", mappingData.GoogleCategoryName);
            p.Add("@GoogleCategoryType", mappingData.GoogleCategoryType);
            p.Add("@NeweggCategoryID", mappingData.NeweggCategoryID);
            p.Add("@IsMasterCategory", mappingData.IsMasterCategory);
            p.Add("@TransactionID", mappingData.TransactionID);
            p.Add("@InUser", mappingData.InUser);
            p.Add("@LastEditUser", mappingData.LastEditUser);
            var webSiteID = dataCommand.ExecuteScalar(p);
            return webSiteID;
        }


        public void DeleteCategoryMappingData(int transactionID)
        {
            var dataCommand = DataCommandManager.GetDataCommand("DeleteCategoryMappingData");
            var p = new DynamicParameters();
            p.Add("@TransactionID", transactionID);
            dataCommand.ExecuteNonQuery(p);
        }

        public string NeweggCategoryIsExists(int neweggCagtegoryID, int transactionID)
        {
            var dataCommand = DataCommandManager.CreateCustomDataCommandFromConfig("NeweggCategoryIsExists");

            var result = string.Empty;

            using (DynamicQuerySqlBuilder sqlBuilder = new DynamicQuerySqlBuilder(dataCommand, "NeweggCategoryID asc"))
            {

                sqlBuilder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "NeweggCategoryID", DbType.Int32, "@NeweggCategoryID", QueryConditionOperatorType.Equal, neweggCagtegoryID);

                sqlBuilder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "IsMasterCategory", DbType.Boolean, "@IsMasterCategory", QueryConditionOperatorType.Equal, true);

                sqlBuilder.ConditionConstructor.AddCondition(QueryConditionRelationType.AND, "Transactionid", DbType.Int32, "@Transactionid", QueryConditionOperatorType.NotEqual, transactionID);

                //查询数据
                dataCommand.CommandText = sqlBuilder.BuildQuerySql();
                var excuteResult = dataCommand.ExecuteScalar();
                result = excuteResult == null ? string.Empty : excuteResult.ToString();
            }

            return result;
        }
    }
}

﻿using Newegg.API.Logging;
using Newegg.Flash.GAPI.Data.Interface;
using Newegg.Oversea.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Newegg.Flash.GAPI.Data.Implement
{
    public class BulkJobRepository : IBulkJob
    {
        public bool BatchOperationExceptionItem(DataSet ds, int webSiteID, string strUser, out int Count)
        {
            ILog log = LogFactory.Log;
            bool bResult = false;
            int iCount = 0;
            string strActiveXML = "<Items>";
            string strDeActiveXML = "<Items>";

            if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
            {

                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    if (string.IsNullOrEmpty(dr["ItemNumber"].ToString().Trim()) || string.IsNullOrEmpty(dr["Status"].ToString().Trim()))
                    {
                        Count = 0;
                        log.Info("ItemNumber（" + dr["ItemNumber"].ToString() + "）\r\nStatus or ItemNumber is null,Transaction rollback !");
                        return false;
                    }

                    if (dr["Status"].ToString().ToUpper().Trim() == "DEACTIVATE")
                    {
                        strDeActiveXML += "<Item><ItemNumber>" + ItemNumberHelper.NeweggItemNumber2ItemNumber(dr["ItemNumber"].ToString().Trim()) + "</ItemNumber></Item>";

                    }
                    else if (dr["Status"].ToString().ToUpper().Trim() == "ACTIVATE")
                    {

                        strActiveXML += "<Item><ItemNumber>" + ItemNumberHelper.NeweggItemNumber2ItemNumber(dr["ItemNumber"].ToString().Trim()) + "</ItemNumber></Item>";

                    }
                    else
                    {
                        Count = 0;
                        log.Info("ItemNumber（" + dr["ItemNumber"].ToString() + "）\r\n Unexpected Status value !");
                        return false;
                    }
                }
                strActiveXML += "</Items>";
                strDeActiveXML += "</Items>";

                IDataReader reader = null;
                bool ret = false; 
                try
                { 
                    var dataCommand = DataCommandManager.GetDataCommand("SaveBulkJobData");
                    var p = new DynamicParameters();
                    p.Add("@ActiveXML", strActiveXML);
                    p.Add("@DeActiveXML", strDeActiveXML);
                     
                    p.Add("@WebSiteID", webSiteID);
                    p.Add("@UserID", strUser);

                    reader = dataCommand.ExecuteDataReader(p); 
                    ret = reader.Read() ? Convert.ToInt32(reader[0]) == 0 : false;

                    if (!ret)
                    {
                        log.Info("Operation data failed，,Transaction rollback ! \r\nMessage:" + reader[1]);
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                   
                    log.Info("Operation data failed，,Transaction rollback ! \r\nMessage:" + ex.Message); 
                    reader.Close();
                }
                bResult = ret;
            }
            Count = iCount;
            return bResult;
        }

    }
}

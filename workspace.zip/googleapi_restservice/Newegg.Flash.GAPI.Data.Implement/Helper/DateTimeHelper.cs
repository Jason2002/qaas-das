﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.Flash.GAPI.Data.Implement
{
    public static class DateTimeHelper
    {
        private static readonly DateTime UNIX_START_TIME = new DateTime(1970, 1, 1);

        public static int ToUnixTimestamp(this DateTime dataTime)
        {
            return (int)dataTime.Subtract(UNIX_START_TIME).TotalSeconds;
        }
    }
}

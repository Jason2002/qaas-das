﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.Flash.GAPI.Data.Interface;
using Newegg.Oversea.DataAccess;
using System.Data;
using Newegg.Flash.GAPI.Data.Interface;

namespace Newegg.Flash.GAPI.Data.Implement
{
    public class ActionLogsRepository : IActionLogs
    {
        public object WriteActionLog(ActionLogs aLogs)
        {
            var dataCommand = DataCommandManager.GetDataCommand("InsertActionLogRecord");
            var p = new DynamicParameters();
            p.Add("@ActionKey", aLogs.ActionKey);
            p.Add("@ActionType", aLogs.ActionType);
            p.Add("@Detail", aLogs.Detail);
            p.Add("@InUser", aLogs.InUser);
            p.Add("@LastEditUser", aLogs.LastEditUser);
            var trNumber = dataCommand.ExecuteScalar(p);
            return trNumber;
        }
    }
}
